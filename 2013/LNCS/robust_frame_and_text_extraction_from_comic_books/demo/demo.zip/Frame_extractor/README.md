========================
LICENCE
========================
CeCILL-B (http://en.wikipedia.org/wiki/CeCILL)


========================
USAGE
========================
java -jar "Frame_extractor.jar" 

