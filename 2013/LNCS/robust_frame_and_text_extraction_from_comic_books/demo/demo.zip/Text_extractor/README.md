========================
LICENCE
========================
CeCILL-B (http://en.wikipedia.org/wiki/CeCILL)


========================
USAGE
========================
java -jar "Text_extractor.jar" 

